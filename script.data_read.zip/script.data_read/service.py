import time
import xbmc
import xbmcgui
import random

if __name__ == '__main__':
    #this is the home window
    win = xbmcgui.Window(10000)
    #get width and height of the screen
    h=win.getHeight()
    w=win.getWidth()
    #put the label in the middle horizontally and 5% down from the top vertically
    ctrl=xbmcgui.ControlLabel(w/2,int(.05*h), 125, 75, '0', 'font16') 
    win.addControl(ctrl)
    win.setFocus(ctrl)
 
    while True:
        #every second set a random number inside the label
        ctrl.setLabel(str(random.randint(0,10)))
        time.sleep(1)